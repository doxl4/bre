package main


var Banner = 	"\033[31mSTRESSID.CLUB | FLOOD BROWSER\n" +
				"%s.us.path% mode=GET/POST url= domain= good= limit= time= threads= [Optional: cookie= data= user_agent= rand_query=]\033[39m\n"
